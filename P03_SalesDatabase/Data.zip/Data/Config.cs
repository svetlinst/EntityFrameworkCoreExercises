﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
    public class Config
    {
        public const string connectionString = @"Server=DESKTOP-1HM340D\SQLEXPRESS;Database=SalesDatabase;Trusted_Connection=True;";
    }
}
